package model;

public class Emenda {
    private String operacao;
    private String nomeParlamentar;
    public Emenda(String operacao, String nomeParlamentar) {
        this.operacao = operacao;
        this.nomeParlamentar = nomeParlamentar;
    }
    public String getOperacao() { return operacao; }
    public String getNomeParlamentar() { return nomeParlamentar; }
}
