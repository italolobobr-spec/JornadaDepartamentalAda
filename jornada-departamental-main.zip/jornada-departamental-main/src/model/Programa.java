package model;


public class Programa {
    private String proposta;
    private String nomePrograma;
    public Programa(String proposta, String nomePrograma) {
        this.proposta = proposta;
        this.nomePrograma = nomePrograma;
    }
    public String getProposta() { return proposta; }
    public String getNomePrograma() { return nomePrograma; }
}
