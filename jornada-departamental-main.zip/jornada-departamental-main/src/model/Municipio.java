package model;

public class Municipio {
    private String proposta;
    private String operacao;
    private String municipio;
    private String uf;

    public Municipio(String proposta, String operacao, String municipio, String uf) {
        this.proposta = proposta;
        this.operacao = operacao;
        this.municipio = municipio;
        this.uf = uf;
    }

    public String getProposta() { return proposta; }
    public String getOperacao() { return operacao; }
    public String getMunicipio() { return municipio; }
    public String getUf() { return uf; }
}
