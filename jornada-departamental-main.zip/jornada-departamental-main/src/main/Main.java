
package main;

import model.Emenda;
import model.Municipio;
import model.Programa;
import service.ConsolidacaoService;
import service.EmendaService;
import service.MunicipioService;
import service.ProgramaService;
import util.LoggerExecucao;
import util.MedidorRecursos;

import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Main otimizado para Java 21 e preparado para Java 25:
 * - Virtual Threads para paralelizar leitura dos CSVs
 * - Compatível com Gatherers (Java 25)
 */
public class Main {
    public static void main(String[] args) {
        Instant inicio = Instant.now();
        try (Scanner scanner = new Scanner(System.in)) {
            String basePath = (args.length > 0) ? args[0] : "";
            System.out.print("Informe a UF (ex: SP) ou 'TODOS': ");
            String filtroUF = scanner.nextLine().trim().toUpperCase();

            var executor = Executors.newVirtualThreadPerTaskExecutor();

            Future<List<Municipio>> municipiosFuture = executor.submit(() ->
                    new MunicipioService(resolveCsv("municipios_beneficiados.csv", basePath)).carregar());
            Future<List<Programa>> programasFuture = executor.submit(() ->
                    new ProgramaService(resolveCsv("programa_acao.csv", basePath)).carregar());
            Future<List<Emenda>> emendasFuture = executor.submit(() ->
                    new EmendaService(resolveCsv("emendaParlamentar.csv", basePath)).carregar());

            List<Municipio> municipios = municipiosFuture.get();
            List<Programa> programas = programasFuture.get();
            List<Emenda> emendas = emendasFuture.get();
            executor.shutdown();

            if (!"TODOS".equals(filtroUF)) {
                municipios = municipios.stream()
                        .filter(m -> m.getUf().equalsIgnoreCase(filtroUF))
                        .toList();
                LoggerExecucao.info("Filtro aplicado: UF = " + filtroUF);
            }

            new ConsolidacaoService(municipios, programas, emendas).gerarCSV("resultado.csv");
            LoggerExecucao.info("Processamento concluído. Registros: " + municipios.size());
        } catch (Exception e) {
            LoggerExecucao.error("Erro: " + e.getMessage());
        } finally {
            MedidorRecursos.exibir(Duration.between(inicio, Instant.now()));
        }
    }

    private static String resolveCsv(String fileName, String basePath) throws Exception {
        // 1) Caminho informado via argumento
        if (!basePath.isBlank()) {
            Path path = Paths.get(basePath, fileName);
            if (Files.exists(path)) return path.toString();
        }
        // 2) Pasta src/csv (ajuste para seu projeto)
        Path fallback = Paths.get("src/csv", fileName);
        if (Files.exists(fallback)) return fallback.toString();
        throw new IllegalArgumentException("Arquivo não encontrado: " + fileName);
    }
}

