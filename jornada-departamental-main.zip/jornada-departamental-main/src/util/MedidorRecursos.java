package util;


import java.time.Duration;

/**
 * MedidorRecursos
 * Classe utilitária para medir tempo de execução e consumo de memória.
 * Compatível com Java 21.
 *
 * Funcionalidades:
 * - Exibir tempo total de execução
 * - Exibir memória usada, memória máxima e percentual de uso
 */
public class MedidorRecursos {

    /**
     * Exibe métricas de tempo e memória no console.
     *
     * @param duracao Duration representando o tempo total de execução
     */
    public static void exibir(Duration duracao) {
        System.out.println("===== MÉTRICAS DE EXECUÇÃO =====");
        System.out.println("Tempo total: " + duracao.toMillis() + " ms (" + duracao.toSeconds() + " s)");

        Runtime rt = Runtime.getRuntime();
        long memoriaUsada = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long memoriaMaxima = rt.maxMemory() / (1024 * 1024);
        double percentualUso = ((double) memoriaUsada / memoriaMaxima) * 100;

        System.out.println("Memória usada: " + memoriaUsada + " MB");
        System.out.println("Memória máxima: " + memoriaMaxima + " MB");
        System.out.printf("Uso percentual: %.2f%%\n", percentualUso);
        System.out.println("===============================");
    }

    /**
     * Retorna memória usada em MB.
     *
     * @return memória usada
     */
    public static long getMemoriaUsadaMB() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
    }

    /**
     * Retorna memória máxima em MB.
     *
     * @return memória máxima
     */

    public static long getMemoriaMaximaMB() {
        return Runtime.getRuntime().maxMemory() / (1024 * 1024);
    }

}