
package service;

import model.Emenda;

import java.util.Optional;

public class EmendaService extends ImportadorCSV<Emenda> {
    public EmendaService(String caminhoArquivo) {
        super(caminhoArquivo);
    }

    @Override
    protected Optional<Emenda> parseLinha(String linha) {
        String[] campos = linha.split(";");
        if (campos.length >= 2) {
            return Optional.of(new Emenda(campos[0], campos[1]));
        }
        return Optional.empty();
    }
}
