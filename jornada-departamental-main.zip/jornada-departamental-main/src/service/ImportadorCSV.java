
package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * ImportadorCSV genérico com suporte a charset configurável.
 */
public abstract class ImportadorCSV<T> {
    protected String caminhoArquivo;
    protected Charset charset;

    public ImportadorCSV(String caminhoArquivo) {
        this(caminhoArquivo, Charset.forName("Cp1252")); // Ajuste para Windows
    }

    public ImportadorCSV(String caminhoArquivo, Charset charset) {
        this.caminhoArquivo = caminhoArquivo;
        this.charset = charset;
    }

    public List<T> carregar() throws IOException {
        List<T> lista = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Path.of(caminhoArquivo), charset)) {
            br.lines().skip(1).forEach(linha -> parseLinha(linha).ifPresent(lista::add));
        }
        return lista;
    }

    protected abstract Optional<T> parseLinha(String linha);
}
