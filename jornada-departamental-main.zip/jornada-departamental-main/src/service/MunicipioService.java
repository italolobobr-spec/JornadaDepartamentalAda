
package service;

import model.Municipio;

import java.util.Optional;

public class MunicipioService extends ImportadorCSV<Municipio> {
    public MunicipioService(String caminhoArquivo) {
        super(caminhoArquivo);
    }

    @Override
    protected Optional<Municipio> parseLinha(String linha) {
        String[] campos = linha.split(";");
        if (campos.length >= 7) {
            return Optional.of(new Municipio(campos[0], campos[2], campos[5], campos[6]));
        }
        return Optional.empty();
    }
}
