
package service;

import model.Programa;

import java.util.Optional;

public class ProgramaService extends ImportadorCSV<Programa> {
    public ProgramaService(String caminhoArquivo) {
        super(caminhoArquivo);
    }

    @Override
    protected Optional<Programa> parseLinha(String linha) {
        String[] campos = linha.split(";");
        if (campos.length >= 4) {
            return Optional.of(new Programa(campos[0], campos[3]));
        }
        return Optional.empty();
    }
}
