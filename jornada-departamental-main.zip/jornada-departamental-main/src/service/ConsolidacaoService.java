
package service;

import model.Emenda;
import model.Municipio;
import model.Programa;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Consolidação compatível com Java 21 usando Collectors.toMap() com merge para chaves duplicadas.
 */
public class ConsolidacaoService {
    private final List<Municipio> municipios;
    private final Map<String, String> programas;
    private final Map<String, String> emendas;

    public ConsolidacaoService(List<Municipio> municipios, List<Programa> programas, List<Emenda> emendas) {
        this.municipios = municipios;
        this.programas = programas.stream()
                .collect(Collectors.toMap(
                        Programa::getProposta,
                        Programa::getNomePrograma,
                        (v1, v2) -> v1 + " | " + v2 // Estratégia de merge
                ));
        this.emendas = emendas.stream()
                .collect(Collectors.toMap(
                        Emenda::getOperacao,
                        Emenda::getNomeParlamentar,
                        (v1, v2) -> v1 + " | " + v2 // Estratégia de merge
                ));
    }

    public void gerarCSV(String arquivoSaida) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Path.of(arquivoSaida), Charset.forName("Cp1252"))) {

            bw.write("municipio_beneficiado;nome_programa;NOME_PARLAMENTAR\n");
            for (Municipio m : municipios) {
                String programa = programas.getOrDefault(m.getProposta(), "N/A");
                String parlamentar = emendas.getOrDefault(m.getOperacao(), "N/A");
                bw.write(String.join(";", m.getMunicipio(), programa, parlamentar));

                bw.newLine();
            }
        }
    }

}
