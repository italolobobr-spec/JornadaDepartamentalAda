
package service;

import model.Emenda;
import model.Municipio;
import model.Programa;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Consolida dados e gera dois arquivos: resultado.csv e inconsistentes.csv.
 */
public class ConsolidacaoService {
    private final List<Municipio> municipios;
    private final Map<String, String> programas;
    private final Map<String, String> emendas;

    public ConsolidacaoService(List<Municipio> municipios, List<Programa> programas, List<Emenda> emendas) {
        this.municipios = municipios;
        this.programas = programas.stream()
                .collect(Collectors.toMap(Programa::getProposta, Programa::getNomePrograma, (v1, v2) -> v1 + " | " + v2));
        this.emendas = emendas.stream()
                .collect(Collectors.toMap(Emenda::getOperacao, Emenda::getNomeParlamentar, (v1, v2) -> v1 + " | " + v2));
    }


    public void gerarResultado(Path caminhoRelatorios) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(caminhoRelatorios.resolve("resultado.csv"), Charset.forName("Cp1252"))){
            bw.write("municipio_beneficiado;UF;nome_programa;nome_parlamentar\n");
            for (Municipio m : municipios) {
                String programa = programas.getOrDefault(m.getProposta(), "N/A");
                String parlamentar = emendas.getOrDefault(m.getOperacao(), "N/A");
                bw.write(String.join(";", m.getMunicipio(),m.getUf(), programa, parlamentar));
                bw.newLine();
            }
        }
    }

    public static void gerarInconsistentes(Path caminhoRelatorios, Map<String, List<Integer>> inconsistentesPorArquivo) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(caminhoRelatorios.resolve("inconsistentes.csv"), Charset.forName("Cp1252"))){
            bw.write("arquivo;num_linha_inconsistente\n");
            for (var entry : inconsistentesPorArquivo.entrySet()) {
                String arquivo = entry.getKey();
                for (Integer linha : entry.getValue()) {
                    bw.write(arquivo + ";" + linha + ";");
                    bw.newLine();
                }
            }
        }
    }


}
