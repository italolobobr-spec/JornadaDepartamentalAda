
package service;

import model.Programa;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * ImportadorCSV genérico com validação de cabeçalho.
 */
public abstract class ImportadorCSV<T> {
    protected String caminhoArquivo;
    protected Charset charset;
    private final String cabecalhoEsperado;
    private final int camposEsperados;
    protected final List<Integer> linhasInconsistentes = new ArrayList<>();


    public ImportadorCSV(String caminhoArquivo, String cabecalhoEsperado) {
        this(caminhoArquivo, Charset.forName("Cp1252"), cabecalhoEsperado);
    }

    public ImportadorCSV(String caminhoArquivo, Charset charset, String cabecalhoEsperado) {
        this.caminhoArquivo = caminhoArquivo;
        this.charset = charset;
        this.cabecalhoEsperado = cabecalhoEsperado;
        this.camposEsperados = cabecalhoEsperado.split(";").length;
    }

    public List<T> carregar() throws IOException {
        List<T> lista = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Path.of(caminhoArquivo), charset)) {
            String cabecalho = br.readLine();
            validarCabecalho(cabecalho);

            int numLinha = 2; // começa após cabeçalho
            String linha;
            while ((linha = br.readLine()) != null) {
                Optional<T> obj = parseLinha(linha);
                if (obj.isPresent()) {
                    lista.add(obj.get());
                } else {
                    linhasInconsistentes.add(numLinha);
                }
                numLinha++;
            }



        }
        return lista;
    }

    private void validarCabecalho(String cabecalho) {

        var cabecalhoSanitizado = sanitizar(cabecalho);
        var cabecalhoEsperadoSanitizado = sanitizar(cabecalhoEsperado);

        if (!cabecalhoSanitizado.equalsIgnoreCase(cabecalhoEsperadoSanitizado)) {

            String arquivo = switch (this){
                case EmendaService e -> "Emenda";
                case MunicipioService m -> "Municipio";
                case ProgramaService e -> "Programa";
                default -> "Inválido";
            };

            throw new IllegalArgumentException("Cabeçalho inválido! Esperado para " + arquivo + ": " + cabecalhoEsperadoSanitizado + ". \nRecebido: " + cabecalhoSanitizado);
        }
    }

    private String sanitizar (String texto){
        return texto.replaceAll("[^a-zA-Z0-9;_]", "");
    }


    public List<Integer> getLinhasInconsistentes() {
        return linhasInconsistentes;
    }

    protected abstract Optional<T> parseLinha(String linha);

    protected int getCamposEsperados () {
        return camposEsperados;
    };
}
