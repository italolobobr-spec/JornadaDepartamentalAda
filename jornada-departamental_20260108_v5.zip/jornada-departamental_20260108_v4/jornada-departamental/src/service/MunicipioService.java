
package service;

import model.Municipio;

import java.util.Optional;

/**
 * Serviço para importar dados de Municípios beneficiados.
 * - Extende ImportadorCSV com validação de cabeçalho.
 * - Usa Builder Pattern para criar objetos Municipio.
 */
public class MunicipioService extends ImportadorCSV<Municipio> {

    public MunicipioService(String caminhoArquivo, String cabecalhoEsperado) {
        super(caminhoArquivo, cabecalhoEsperado);
    }

    @Override
    protected Optional<Municipio> parseLinha(String linha) {
        String[] campos = linha.split(";");

        if (campos.length == getCamposEsperados()) {
            return Optional.of(new Municipio.Builder()
                    .proposta(campos[0].trim())
                    .operacao(campos[2].trim())
                    .municipio(campos[5].trim())
                    .uf(campos[6].trim())
                    .build());
        }
        return Optional.empty();
    }
}

