
package service;

import model.Programa;

import java.util.Optional;

/**
 * Serviço para importar dados de Programas.
 * - Extende ImportadorCSV com validação de cabeçalho.
 * - Usa Builder Pattern para criar objetos Programa.
 */
public class ProgramaService extends ImportadorCSV<Programa> {

    public ProgramaService(String caminhoArquivo, String cabecalhoEsperado) {
        super(caminhoArquivo, cabecalhoEsperado);
    }

    @Override
    protected Optional<Programa> parseLinha(String linha) {
        String[] campos = linha.split(";");
        if (campos.length == getCamposEsperados()) {
            return Optional.of(new Programa.Builder()
                    .proposta(campos[0].trim())
                    .nomePrograma(campos[3].trim())
                    .build());
        }
        return Optional.empty();
    }
}
