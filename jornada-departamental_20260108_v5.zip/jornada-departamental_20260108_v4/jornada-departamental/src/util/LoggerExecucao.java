
package util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * LoggerExecucao
 * Classe utilitária para registrar logs no console e em arquivo.
 * Agora inclui contador de linhas inconsistentes.
 */
public class LoggerExecucao {

    private static final String LOG_FILE = "execucao.log";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static int infoCount = 0;
    private static int warnCount = 0;
    private static int errorCount = 0;
    private static int inconsistentesCount = 0;

    public static synchronized void info(String mensagem) {
        infoCount++;
        registrar("INFO", mensagem);
    }

    public static synchronized void warn(String mensagem) {
        warnCount++;
        registrar("WARN", mensagem);
    }

    public static synchronized void error(String mensagem) {
        errorCount++;
        registrar("ERROR", mensagem);
    }

    /**
     * Registra quantidade de inconsistências no log e incrementa contador.
     */
    public static synchronized void inconsistentes(int quantidade) {
        inconsistentesCount += quantidade;
        registrar("INCONSISTENTES", "Total de linhas inconsistentes adicionadas: " + quantidade);
    }

    private static void registrar(String nivel, String mensagem) {
        LocalDateTime agora = LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
        String timestamp = FORMATTER.format(agora);
        String logLine = String.format("[%s] [%s] %s", timestamp, nivel, mensagem);

        System.out.println(logLine);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            bw.write(logLine);
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Falha ao gravar log no arquivo: " + e.getMessage());
        }
    }

    /**
     * Exibe resumo das métricas de log.
     */
    public static synchronized void exibirResumo() {
        System.out.println("===== RESUMO DE LOG =====");
        System.out.println("INFO: " + infoCount);
        System.out.println("WARN: " + warnCount);
        System.out.println("ERROR: " + errorCount);
        System.out.println("INCONSISTENTES: " + inconsistentesCount);
        System.out.println("=========================");
    }
}
