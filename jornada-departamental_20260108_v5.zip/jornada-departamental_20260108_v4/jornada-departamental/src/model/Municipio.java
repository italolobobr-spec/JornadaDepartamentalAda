
package model;

/**
 * Representa um município beneficiado por uma proposta.
 * Encapsulamento + Builder Pattern para imutabilidade opcional.
 */
public class Municipio {
    private final String proposta;
    private final String operacao;
    private final String municipio;
    private final String uf;

    private Municipio(Builder builder) {
        this.proposta = builder.proposta;
        this.operacao = builder.operacao;
        this.municipio = builder.municipio;
        this.uf = builder.uf;
    }

    public String getProposta() { return proposta; }
    public String getOperacao() { return operacao; }
    public String getMunicipio() { return municipio; }
    public String getUf() { return uf; }

    @Override
    public String toString() {
        return String.format("Municipio{proposta='%s', operacao='%s', municipio='%s', uf='%s'}",
                proposta, operacao, municipio, uf);
    }

    public static class Builder {
        private String proposta;
        private String operacao;
        private String municipio;
        private String uf;

        public Builder proposta(String proposta) { this.proposta = proposta; return this; }
        public Builder operacao(String operacao) { this.operacao = operacao; return this; }
        public Builder municipio(String municipio) { this.municipio = municipio; return this; }
        public Builder uf(String uf) { this.uf = uf; return this; }

        public Municipio build() {
            if (proposta == null || operacao == null || municipio == null || uf == null) {
                throw new IllegalStateException("Todos os campos devem ser preenchidos");
            }
            return new Municipio(this);
        }
    }
}
