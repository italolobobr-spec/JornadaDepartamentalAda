
package model;

public class Programa {
    private final String proposta;
    private final String nomePrograma;

    private Programa(Builder builder) {
        this.proposta = builder.proposta;
        this.nomePrograma = builder.nomePrograma;
    }

    public String getProposta() { return proposta; }
    public String getNomePrograma() { return nomePrograma; }

    @Override
    public String toString() {
        return String.format("Programa{proposta='%s', nomePrograma='%s'}", proposta, nomePrograma);
    }

    public static class Builder {
        private String proposta;
        private String nomePrograma;

        public Builder proposta(String proposta) { this.proposta = proposta; return this; }
        public Builder nomePrograma(String nomePrograma) { this.nomePrograma = nomePrograma; return this; }

        public Programa build() {
            if (proposta == null || nomePrograma == null) {
                throw new IllegalStateException("Campos obrigatórios não preenchidos");
            }
            return new Programa(this);
        }
    }
}
