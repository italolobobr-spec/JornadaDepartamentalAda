
# 📌 Projeto: Busca por Programas e Parlamentares por UF
*(Cruzamento de Dados CSV com Filtro por UF — Java 25 + Quarkus)*

## ✅ Descrição
Este projeto implementa um sistema orientado a objetos para **cruzar dados de três arquivos CSV públicos**:

- `municipios_beneficiados.csv`
- `programa_acao.csv`
- `emendaParlamentar.csv`

O objetivo é consolidar informações sobre **municípios beneficiados**, **programas** e **parlamentares**, permitindo **filtragem por UF** ou processamento completo.

> ℹ️ Os arquivos são somente leitura: o usuário **não** altera os dados de origem.

---

## ✨ Funcionalidades
- Importação com **validação de cabeçalho** (processa apenas se forem válidos).
- Geração de dois arquivos de saída:
  - `resultado.csv` → dados consolidados (`municipio_beneficiado;UF;nome_programa;NOME_PARLAMENTAR`).
  - `inconsistentes.csv` → traz o nome do arquivo com o número da linha inconsistente.
- **Filtro por UF** (ex.: `SP`, `MG`) ou opção **Todos** para processar tudo.
- **Log detalhado** em `execucao.log` que ficará gravado na raiz do projeto.
- Exibição de **métricas de execução** (tempo total e memória usada) no console.

---

## 🗂️ Estrutura do Projeto
```
src/
├── csv/          # Arquivos CSV de entrada
├── main/         # Main.java
├── model/        # Classes de domínio (Municipio.java, Programa.java, Emenda.java)
├── service/      # Serviços de importação e consolidação
└── util/         # Utilitários (LoggerExecucao.java, MedidorRecursos.java)
```

---

## 🔧 Pré-requisitos
- **Java 21** ou superior.
- Recomendado: **Java 25** para recursos avançados:
  - Stream Gatherers (JEP 485)
  - Structured Concurrency
  - Virtual Threads
- **Maven** ou **Gradle** para build (opcional).
- **Quarkus** (se desejar rodar em modo dev e empacotar como app Quarkus).

---

## 🚀 Como Executar
### Opção A — Execução direta (Main)
1. Baixe os arquivos e execute o Main.java:
   
2. Informe, quando solicitado:
   - Caminho do arquivo `emendaParlamentar.csv`
   - Caminho do arquivo `programa_acao.csv`
   - Caminho do arquivo `municipios_beneficiados.csv`
   - Caminho para gravação dos arquivos de saída
   - UF para filtrar (ex.: `SP`, `MG`) ou `Todos`

```

---

## 📤 Saídas
- **Arquivo consolidado:** `resultado.csv`
- **Arquivo de inconsistentes:** `inconsistentes.csv`
- **Log detalhado:** `execucao.log`
- **Métricas no console:**
  ```
  Tempo total: 1234 ms
  Memória usada: 45 MB
  ```

---

## 🧪 Validação e Tratamento de Erros
- **Cabeçalhos inválidos:** lança exceção e **interrompe** o processamento.
- **Erros de leitura/escrita:** logados em `execucao.log` com contexto.
- **Registros incompletos:** direcionados para `inconsistentes.csv`.

---

## 📚 Exemplo de Sessão (interativa)
```
Informe o caminho e nome do arquivo da Emenda: c:/Temp/emendaParlamentar.csv
Informe o caminho e nome do arquivo do Programa: c:/Temp/programa_acao.csv
Informe o caminho e nome do arquivo de Municípios: c:/Temp/municipios_beneficiados.csv
Informe o local para gravação dos arquivos: c:/Temp/
Informe a UF para filtrar (ex.: SP, MG) ou 'Todos' para não filtrar: SP

```

**Saída gerada:**
- `c:/Temp/resultado.csv`
- `c:/Temp/inconsistentes.csv`
- `c:/Temp/execucao.log`
---

## 👤 Autores

Projeto mantido por: 
**Alex Cardoso Galvão**.
**Arnóbio José Tavares da Silva Júnior**.
**Daniel Valerio Moraes**.
**Italo Lobo e Bonfim**.


