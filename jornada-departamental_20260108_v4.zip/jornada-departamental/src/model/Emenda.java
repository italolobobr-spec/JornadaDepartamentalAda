
package model;

public class Emenda {
    private final String operacao;
    private final String nomeParlamentar;

    private Emenda(Builder builder) {
        this.operacao = builder.operacao;
        this.nomeParlamentar = builder.nomeParlamentar;
    }

    public String getOperacao() { return operacao; }
    public String getNomeParlamentar() { return nomeParlamentar; }

    @Override
    public String toString() {
        return String.format("Emenda{operacao='%s', nomeParlamentar='%s'}", operacao, nomeParlamentar);
    }

    public static class Builder {
        private String operacao;
        private String nomeParlamentar;

        public Builder operacao(String operacao) { this.operacao = operacao; return this; }
        public Builder nomeParlamentar(String nomeParlamentar) { this.nomeParlamentar = nomeParlamentar; return this; }

        public Emenda build() {
            if (operacao == null || nomeParlamentar == null) {
                throw new IllegalStateException("Campos obrigatórios não preenchidos");
            }
            return new Emenda(this);
        }
    }
}
