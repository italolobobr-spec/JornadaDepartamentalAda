
package service;

import model.Emenda;

import java.util.Optional;

/**
 * Serviço para importar dados de Emendas Parlamentares.
 * - Extende ImportadorCSV com validação de cabeçalho.
 * - Usa Builder Pattern para criar objetos Emenda.
 */
public class EmendaService extends ImportadorCSV<Emenda> {

    public EmendaService(String caminhoArquivo, String cabecalhoEsperado) {
        super(caminhoArquivo, cabecalhoEsperado);
    }

    @Override
    protected Optional<Emenda> parseLinha(String linha) {
        String[] campos = linha.split(";");

        if (campos.length == getCamposEsperados()) {
            return Optional.of(new Emenda.Builder()
                    .operacao(campos[0].trim())
                    .nomeParlamentar(campos[1].trim())
                    .build());
        }
        return Optional.empty();
    }
}
