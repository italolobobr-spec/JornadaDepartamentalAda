
package main;

import model.Emenda;
import model.Municipio;
import model.Programa;
import service.ConsolidacaoService;
import service.EmendaService;
import service.MunicipioService;
import service.ProgramaService;
import util.LoggerExecucao;
import util.MedidorRecursos;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Classe Main:
 * - Solicita ao usuário o caminho completo dos arquivos CSV.
 * - Valida se cada caminho existe antes de continuar.
 * - Usa Virtual Threads (Java 21) para leitura paralela.
 * - Consolida dados e gera dois arquivos: resultado.csv e inconsistentes.csv.
 */
public class Main {
    public static void main(String[] args) {
        Instant inicio = Instant.now();
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("=== PROCESSAMENTO DE DADOS ===");

            // Solicita caminhos completos com validação
            String caminhoMunicipios = solicitarCaminho(scanner, "Informe o caminho completo do arquivo MUNICÍPIOS (municipios_beneficiados.csv): ");
            String caminhoProgramas = solicitarCaminho(scanner, "Informe o caminho completo do arquivo PROGRAMAS (programa_acao.csv): ");
            String caminhoEmendas = solicitarCaminho(scanner, "Informe o caminho completo do arquivo EMENDAS (emendaParlamentar.csv): ");

            Path caminhoRelatorios = Paths.get(solicitarCaminho(scanner, "Informe o caminho para gravar os relatórios: "));

            System.out.print("Informe a UF (ex: SP) ou 'TODOS': ");
            String filtroUF = scanner.nextLine().trim().toUpperCase();

            // Executor com Virtual Threads (Java 21)
            var executor = Executors.newVirtualThreadPerTaskExecutor();

            // Instancia serviços com cabeçalhos esperados
            MunicipioService municipioService = new MunicipioService(caminhoMunicipios, "proposta;convenio;operacao;srf_municipio;ibge_nu;municipio_beneficiado;uf");
            ProgramaService programaService = new ProgramaService(caminhoProgramas,"PROPOSTA;CONVENIO;COD_PROGRAMA;NOME_PROGRAMA;COD_ACAO_ORCAMENTARIA;FUNCIONAL");
            EmendaService emendaService = new EmendaService(caminhoEmendas,"OPERACAO;NOME_PARLAMENTAR");

            // Submissão das tarefas de leitura paralela
            Future<List<Municipio>> municipiosFuture = executor.submit(municipioService::carregar);
            Future<List<Programa>> programasFuture = executor.submit(programaService::carregar);
            Future<List<Emenda>> emendasFuture = executor.submit(emendaService::carregar);

            // Aguarda resultados
            List<Municipio> municipios = municipiosFuture.get();
            List<Programa> programas = programasFuture.get();
            List<Emenda> emendas = emendasFuture.get();
            executor.shutdown();

            // Aplica filtro por UF (se não for TODOS)
            if (!"TODOS".equals(filtroUF)) {
                municipios = municipios.stream()
                        .filter(m -> m.getUf().equalsIgnoreCase(filtroUF))
                        .toList();
                LoggerExecucao.info("Filtro aplicado: UF = " + filtroUF);
            }

            // Consolidação e geração dos arquivos

            Map<String, List<Integer>> inconsistentesMap = new HashMap<>();
            inconsistentesMap.put("municipios_beneficiados.csv", municipioService.getLinhasInconsistentes());
            inconsistentesMap.put("programa_acao.csv", programaService.getLinhasInconsistentes());
            inconsistentesMap.put("emendaParlamentar.csv", emendaService.getLinhasInconsistentes());

            ConsolidacaoService consolidacao = new ConsolidacaoService(municipios, programas, emendas);
            consolidacao.gerarResultado(caminhoRelatorios);
            ConsolidacaoService.gerarInconsistentes(caminhoRelatorios, inconsistentesMap);


            int totalInconsistentes = municipioService.getLinhasInconsistentes().size()
                    + programaService.getLinhasInconsistentes().size()
                    + emendaService.getLinhasInconsistentes().size();

            LoggerExecucao.inconsistentes(totalInconsistentes);
            LoggerExecucao.info("Processamento concluído. Registros: " + municipios.size());

        } catch (Exception e) {
            LoggerExecucao.error("Erro: " + e.getMessage());
        } finally {
            MedidorRecursos.exibir(Duration.between(inicio, Instant.now()));
        }
    }

    /**
     * Solicita ao usuário um caminho e valida se o arquivo existe.
     * Repete até que seja válido.
     */
    private static String solicitarCaminho(Scanner scanner, String mensagem) {
        String caminho;
        while (true) {
            System.out.print(mensagem);
            caminho = scanner.nextLine().trim();
            if (Files.exists(Path.of(caminho))) {
                return caminho;
            } else {
                System.out.println("Caminho inválido. Tente novamente.");
            }
        }
    }

}
